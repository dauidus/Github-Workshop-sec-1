import random

def ask():
  print('Do you dare to play rock, paper, sissors against me?')
  print('Pick rock, paper, or sissors:')

def playerchoice():
  return input().lower()


#b = playerchoice()

def computerchoice():
  answers = ['Rock', 'Paper', 'Sissors']
  return answers[random.randint(0, len(answers)-1)]

def show(q, answer):
  print('You picked:',q)
  print('I chose:', answer)

ask()

show(playerchoice(), computerchoice())

#a = computerchoice()

#if b =='paper' and a== 'Paper':
  #print('No one wins')

#if b =='paper' and a=='Rock':
  #print('You win')

#if b =='paper' and a=='Sissors':
  #print('I win')

#if b =='rock' and a=='Rock':
  #print('No one wins')

#if b =='rock' and a=='Paper':
  #print('I win')

#if b =='rock' and a=='Sissors':
  #print('You win')

#if b =='sissors' and a=='Rock':
  #print('I win')

#if b =='sissors' and a=='Paper':
  #print('You win')
#else:
  #print('I win')