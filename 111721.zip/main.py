import random

Rooms = {'Entrance':'You are in the first of a large door.',\
        'Hallway': 'The hallway is dinly lit.'}

#print(Rooms['Entance'])
#print(Rooms['Hallway'])

Maps = {'Hallway': '\
         ____________\n \
        |           |\n \
         ____________'}

print(Maps['Hallway'])
print(Rooms['Hallway'])

Player = {'Inventory': ['coin', 'knife', 'note']}

Player['Stats']={'Strength':10}

Player['Inventory'].append('rock')
print('You pick up a rock.')
print('You have:')
for item in Player['Inventory']:
  print(item)

print(Player['Stats']['Strength'])

Categories = ['Animals', 'Cars']

Words = {'Animals': ['zebra', 'giraffe', 'elephant'], \
        'Cars': ['Tesla', 'Ford', 'Toyota']}

category=Categories[random.randint(0,len(Categories)-1)]

guessword= Words[category][random.randint(0,len(Words[category])-1)]
#guessword = Words[cat][0]
print(guessword)